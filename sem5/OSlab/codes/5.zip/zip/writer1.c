
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include<string.h>


int main()
{
	

	// shmat to attach to shared memory
	//printf("hi1");
	FILE* f1=fopen("week05-ML2-input.txt","r");
	int shmid;
	//printf("hi2");
	char* str;
	for(int j=0;j<100;j++)
	{
		
	// shmget returns an identifier in shmid
		//printf("hi1");
		key_t key = ftok("week05-ML2-input.txt",65);
		//printf("hi2");
		char str1[1024*32*4];
		//printf("hi3");
		shmid = shmget(key,1024,0666|IPC_CREAT);
		//shmctl(shmid,IPC_RMID,NULL);
		//printf("hi4");
		 str = (char*) shmat(shmid,(void*)0,0);
		//printf("hi5");
		
		int i=0;
		while(i!=30)
		{
			char c[512];
			fgets(c,512,f1);
			strcat(str1,c);
			i++;
		}
		
		//printf("hi6\n");
		strcpy(str,str1);
		//printf("hi7\n");
		//printf("Data written in memory: %s\n",str);
		//printf("hi8\n");
		
		//detach from shared memory
		
	}
	printf("hi10\n");
	shmdt(str);
	printf("hi11\n");
	shmctl(shmid,IPC_RMID,NULL);
	//printf("hi1");
	//char str1[10000];
	//printf("hi2");

	//printf("Write Data : ");
	/*
	while(f1!=EOF)
	{
		FILE* f1=fopen("week05-ML2-input.txt","r");
		char c[256];
		//printf("%d",f1);
		//char b=fgetc(f1);
		fgets(c,256,f1);
		//printf("%s",c);
		int i=0;
		int j=0;
		while(1)
		{
			if(c[j]==' ')
			{
				i++;
			}
			if(i==3)
			{
				if(c[j]==)
			}
			j++;
		}
		
	}
	*/
	
	//char c[512];
	

	return 0;
}
