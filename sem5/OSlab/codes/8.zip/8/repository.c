#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <unistd.h>

#define MAX_SHM 1024

union semun {
	int val;              /* used for SETVAL only */
	struct semid_ds *buf; /* for IPC_STAT and IPC_SET */
	ushort *array;        /* used for GETALL and SETALL */
};

void sem_wait(int semid,struct sembuf* sb)
{
    // (*sb)={0,-1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=-1;
    (*sb).sem_flg=0;

    if (semop(semid, sb, 1) == -1)
    {
    perror("semop");
    exit(1);
    }



}

void sem_signal(int semid,struct sembuf* sb)
{
    // *sb ={0,1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=1;
    (*sb).sem_flg=0;

    if (semop(semid,sb, 1) == -1) 
    {
    perror("semop");
    exit(1);
    }
}

int main(void)
{
	key_t key = ftok("repository.c",65);
	
	int shmid = shmget(key,MAX_SHM,0666|IPC_CREAT);
	
	char* str = (char*) shmat(shmid,(void*)0,0);
	
	strcpy(str,"Hello world!\n");
}


