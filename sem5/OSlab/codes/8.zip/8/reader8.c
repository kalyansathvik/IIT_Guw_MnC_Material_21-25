#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <unistd.h>
#include <wait.h>

union semun {
	int val;              /* used for SETVAL only */
	struct semid_ds *buf; /* for IPC_STAT and IPC_SET */
	ushort *array;        /* used for GETALL and SETALL */
};

void sem_wait(int semid,struct sembuf* sb)
{
    // (*sb)={0,-1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=-1;
    (*sb).sem_flg=0;

    if (semop(semid, sb, 1) == -1)
    {
    perror("semop");
    exit(1);
    }



}

void sem_signal(int semid,struct sembuf* sb)
{
    // *sb ={0,1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=1;
    (*sb).sem_flg=0;

    if (semop(semid,sb, 1) == -1) 
    {
    perror("semop");
    exit(1);
    }
}

int main(void)
{
	key_t key1,key2,key3;
    int semid,shmid,semid1;
    union semun arg;
    struct sembuf sb = {0, -1, 0};  /* set to allocate resource */
    
    if ((key1 = ftok("repository.c", 65 )) == -1) {
    perror("ftok");
    exit(1);
    }
    
     /* connect to (and possibly create) the segment: */
    if ((shmid = shmget(key1, 100, 0666 | IPC_CREAT)) == -1) {
    perror("shmget");
    exit(1);
    }
    
    char* data=shmat(shmid, (void *)0, 0);
    
    if ((key2 = ftok("writer8.c", 'b')) == -1) {
    perror("ftok");
    exit(1);
    }

	if ((key3 = ftok("reader8.c", 'b')) == -1) {
    perror("ftok");
    exit(1);
    }
    
    if ((semid1 = semget(key2, 1, 0666|IPC_CREAT)) == -1) {
        perror("semget");
        exit(1);
    }
    
    if ((semid = semget(key3, 1, 0666|IPC_CREAT)) == -1) {
        perror("semget");
        exit(1);
    }
    
    

    arg.val = 1;
    if (semctl(semid, 0, SETVAL, arg) == -1) {
        perror("semctl");
        exit(1);
    }
    
   /* for(int i=0;i<5;i++)
    {
    	pid_t pid=fork();
    	if(pid==0)
    	{*/
    		int i=0;
			sem_wait(semid,&sb);
			char *str = (char*) shmat(shmid,(void*)0,0);
			printf("Data read from memory: %s\n",str);
			printf("No of readers: %d",i)
			sem_signal(semid,&sb);
		/*}
		else
		{
			int status;
			wait(&status);
		}
    }*/

}
