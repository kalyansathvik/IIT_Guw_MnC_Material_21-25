f.u can see that when i run two write programs with the (sleep function not commented) the other write is waiting for the signal

g.same as f with sleep in reader uncommented

h.same as f with the sleep in both the readers uncommented

I HAVE KEPT THE SLEEP UNCOMMENTED IN BOTH THE PROGRAMS BY DEFAULT
