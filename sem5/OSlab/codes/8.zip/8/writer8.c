#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <unistd.h>
#include <sys/wait.h>


union semun {
	int val;              /* used for SETVAL only */
	struct semid_ds *buf; /* for IPC_STAT and IPC_SET */
	ushort *array;        /* used for GETALL and SETALL */
};

void sem_wait(int semid,struct sembuf* sb)
{
    // (*sb)={0,-1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=-1;
    (*sb).sem_flg=0;

    if (semop(semid, sb, 1) == -1)
    {
    perror("semop");
    exit(1);
    }



}

void sem_signal(int semid,struct sembuf* sb)
{
    // *sb ={0,1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=1;
    (*sb).sem_flg=0;

    if (semop(semid,sb, 1) == -1) 
    {
    perror("semop");
    exit(1);
    }
}

int main(void)
{
    key_t key1,key2;
    int semid,shmid;
    union semun arg;
    struct sembuf sb = {0, -1, 0};  /* set to allocate resource */

    
    if ((key1 = ftok("repository.c", 65 )) == -1) {
    perror("ftok");
    exit(1);
    }
    
     /* connect to (and possibly create) the segment: */
    if ((shmid = shmget(key1, 100, 0666 | IPC_CREAT)) == -1) {
    perror("shmget");
    exit(1);
    }
    
    char* data=shmat(shmid, (void *)0, 0);
    
    if ((key2 = ftok("writer8.c", 'b')) == -1) {
    perror("ftok");
    exit(1);
    }

    if ((semid = semget(key2, 1, 0666|IPC_CREAT)) == -1) {
        perror("semget");
        exit(1);
    }

    arg.val = 1;
    if (semctl(semid, 0, SETVAL, arg) == -1) {
        perror("semctl");
        exit(1);
    }

	//for(int i=0;i<5;i++)
	//{
		 //pid_t pd=fork();
		 //if(pd==0)
		 //{
		 sem_wait(semid,&sb);
		 printf("%d\n",(sb).sem_num);
		 printf("%d\n",(sb).sem_op);
		 printf("%d\n",(sb).sem_flg);
		 strcat(data,"hello written by pid: ");
		 char data2[10];
		 int pid=getpid();
		 sprintf(data2,"%d\n",pid);
		 strcat(data,data2);
		 sleep(10);
		 sem_signal(semid,&sb);
		 printf("%d\n",(sb).sem_num);
		 printf("%d\n",(sb).sem_op);
		 printf("%d\n",(sb).sem_flg);
		 exit(0);
		 /*}
		 else
		 {
		 	//int status;
		 	//wait(&status);
		 }*/
	//}
	
	exit(0);
	return 0;
		 
}
   

