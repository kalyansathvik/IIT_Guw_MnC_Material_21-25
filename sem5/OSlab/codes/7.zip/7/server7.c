#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <unistd.h>

#define MAX_SIZE 100

int siggu=0;

union semun {
	int val;              /* used for SETVAL only */
	struct semid_ds *buf; /* for IPC_STAT and IPC_SET */
	ushort *array;        /* used for GETALL and SETALL */
};

void sem_wait(int semid,struct sembuf* sb)
{
    // (*sb)={0,-1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=-1;
    (*sb).sem_flg=0;

    if (semop(semid, sb, 1) == -1)
    {
    perror("semop");
    exit(1);
    }



}

void sem_signal(int semid,struct sembuf* sb)
{
    // *sb ={0,1,0};
    (*sb).sem_num=0;
    (*sb).sem_op=1;
    (*sb).sem_flg=0;

    if (semop(semid,sb, 1) == -1) 
    {
    perror("semop");
    exit(1);
    }
}

typedef struct {
    int data[MAX_SIZE];
    int front;
    int rear;
    int size;
} Deque;

// Initialize an empty deque
void initDeque(Deque *deque) {
    deque->front = -1;
    deque->rear = -1;
    deque->size = 0;
}

// Check if the deque is empty
int isEmpty(Deque *deque) {
    return deque->size == 0;
}

// Check if the deque is full
int isFull(Deque *deque) {
    return deque->size == MAX_SIZE;
}

// Add an element to the front of the deque
void addToFront(Deque *deque, int value) {
    if (isFull(deque)) {
        printf("Deque is full. Cannot add.\n");
        return;
    }

    if (isEmpty(deque)) {
        deque->front = 0;
        deque->rear = 0;
    } else if (deque->front == 0) {
        deque->front = MAX_SIZE - 1;
    } else {
        deque->front--;
    }

    deque->data[deque->front] = value;
    deque->size++;
}

// Add an element to the rear of the deque
void addToRear(Deque *deque, int value) {
    if (isFull(deque)) {
        printf("Deque is full. Cannot add.\n");
        return;
    }

    if (isEmpty(deque)) {
        deque->front = 0;
        deque->rear = 0;
    } else if (deque->rear == MAX_SIZE - 1) {
        deque->rear = 0;
    } else {
        deque->rear++;
    }

    deque->data[deque->rear] = value;
    deque->size++;
}

// Remove an element from the front of the deque
int removeFromFront(Deque *deque) {
    if (isEmpty(deque)) {
        printf("Deque is empty. Cannot remove.\n");
        return -1;
    }

    int removedValue = deque->data[deque->front];

    if (deque->front == deque->rear) {
        deque->front = -1;
        deque->rear = -1;
    } else if (deque->front == MAX_SIZE - 1) {
        deque->front = 0;
    } else {
        deque->front++;
    }

    deque->size--;
    return removedValue;
}

// Remove an element from the rear of the deque
int removeFromRear(Deque *deque) {
    if (isEmpty(deque)) {
        printf("Deque is empty. Cannot remove.\n");
        return -1;
    }

    int removedValue = deque->data[deque->rear];

    if (deque->front == deque->rear) {
        deque->front = -1;
        deque->rear = -1;
    } else if (deque->rear == 0) {
        deque->rear = MAX_SIZE - 1;
    } else {
        deque->rear--;
    }

    deque->size--;
    return removedValue;
}


int main(void)
{
    key_t key1,key2;
    int semid,shmid;
    union semun arg;
    struct sembuf sb = {0, -1, 0};  /* set to allocate resource */

    

    if ((key1 = ftok("server7.c", 'a')) == -1) {
    perror("ftok");
    exit(1);
    }

    /* connect to (and possibly create) the segment: */
    if ((shmid = shmget(key1, 100, 0666 | IPC_CREAT)) == -1) {
    perror("shmget");
    exit(1);
    }

    if ((key2 = ftok("server7.c", 'b')) == -1) {
    perror("ftok");
    exit(1);
    }

    if ((semid = semget(key2, 1, 0666|IPC_CREAT)) == -1) {
        perror("semget");
        exit(1);
    }

    arg.val = 1;
    if (semctl(semid, 0, SETVAL, arg) == -1) {
        perror("semctl");
        exit(1);
    }

    int count=0;

    for(int i=0;i<2;i++)
    {
        pid_t pid=fork();
        if(pid>0)
        {
            exit(0);
        }
        else if(pid<0)
        {
            perror("Fork failed");
            exit(1);
        }
        else
        {
            
            // if (data == (char *)(-1)) {
            // perror("shmat");
            // exit(1);
            // }

            

            
            Deque* queue= shmat(shmid, (void *)0, 0);
            
            while((!isEmpty(queue) || siggu==0)&& count<100)
            {
                sem_wait(semid,&sb);
                
               
                
                if(!isEmpty(queue))
                {
                    printf("Front element: %d\n", (*queue).data[(*queue).front]);
                    removeFromFront(queue);
                    count++;
                    siggu=1;
                }
                // else
                // {
                //     printf("hi\n");
                // }
                
                
                
                sem_signal(semid,&sb);
            }

            if (shmdt(queue) == -1) {
                perror("shmdt");
                exit(1);
            }

            /* remove it: */
            arg.val=0;
            if (semctl(semid, 0, IPC_RMID, arg) == -1) {
            perror("semctl");
            exit(1);
            }

           
            

                        

            


        }

    }



}