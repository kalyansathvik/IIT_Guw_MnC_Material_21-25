#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include<string.h>
#include<math.h>

struct my_msgbuf {
	long mtype;
	int row_number;
	int column_number;
};

int main(void)
{

	FILE* f1=fopen("ML2-input.txt","r");
	int xx,xy;
	fscanf(f1,"%d %d",&xx,&xy);
	int kx[3][3];
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			fscanf(f1,"%d",&kx[i][j]);
		}
	}
	
	int yx,yy;
	fscanf(f1,"%d %d",&yx,&yy);
	int ky[3][3];
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			fscanf(f1,"%d",&ky[i][j]);
		}
	}
	
	int ix,iy;
	fscanf(f1,"%d %d",&ix,&iy);
	int ii[256][256];
	for(int i=0;i<256;i++)
	{
		for(int j=0;j<256;j++)
		{
			fscanf(f1,"%d",&ii[i][j]);
		}
	}
	
	
	
	
	struct my_msgbuf buf;
	int msqid;
	key_t key;
	if ((key = ftok("kirk.c", 'B')) == -1) {
		perror("ftok");
		//exit(1);
	}
	
/* same key as kirk.c */
	if ((msqid = msgget(key, 0666)) == -1) { /* connect to the queue */
		perror("msgget");
		//exit(1);
	}
	
//printf("spock: ready to receive messages, captain.\n");
//for(;;) { /* Spock never quits! */
	FILE* f2=fopen("output.txt","w");
	int r=buf.row_number;
	int c=buf.column_number;

	for(int r=1;r<255;r++)
	{
		for(int c=1;c<255;c++)
		{
			/*
			if (msgrcv(msqid, (struct msgbuf *)&buf, sizeof(buf), 0, 0) == -1) {
			perror("msgrcv");
			exit(1);
			}
			*/
			
			//printf("%d\n",r);
			
			int ans1=0;
			for(int i=-1;i<2;i++)
			{
				for(int j=-1;j<2;j++)
				{
					ans1+=ii[r+i][c+i]*kx[i+1][j+1];
				}
			}
			
			
			int ans2=0;
			for(int i=-1;i<2;i++)
			{
				for(int j=-1;j<2;j++)
				{
					ans2+=ii[r+i][c+i]*ky[i+1][j+1];
				}
			}
			
			float ans=sqrt(ans1*ans1+ans2*ans2);
			if(ans>255)
			ans=255;
			fprintf(f2,"%d %d:%f\n",r,c,ans);
			
			
		}
	}
	
	
	
	
	//printf("spock: \"%s\"\n", buf.mtext);
}


