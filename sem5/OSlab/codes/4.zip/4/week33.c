#include <stdio.h>

#include <sys/types.h>

#include <unistd.h>
#include<string.h>
#include<stdlib.h>


int main() {

	char string[255];
	fgets(string,255,stdin);
	//printf("hi3");
	//printf("%s",string);
	if(strncmp(string,"./compute_sequence_1| ./compute_sequence_2\n",strlen("./compute_sequence_1| ./compute_sequence_2\n"))==0)
	{
		//printf("hi1");
		int pipe_fd[2];
		//printf("hi10");
		pipe(pipe_fd);
		//printf("hi9");
		pid_t child_pid;
		//printf("hi8");
		child_pid=fork();
		if (child_pid != 0) { 
			
		    //printf("hi4");
		    close(pipe_fd[0]);  
		    //printf("hi15");
		    dup2(pipe_fd[1], STDOUT_FILENO);  
		    //printf("hi16");
		    char b[]="./compute_sequence_2\n";
		    //printf("hi17");
		    close(pipe_fd[1]); 
		    //printf("hi18");
		     execl(b,b,NULL);
		     //printf("hi19");
		} else {  
			//printf("hi");
		    close(pipe_fd[1]); 
		    //printf("hi7");
		    dup2(pipe_fd[0], STDIN_FILENO); 
		    //printf("hi11");
		    char a[]="./compute_sequence_1\n";
		    //printf("hi12");
		    close(pipe_fd[0]); 
		    //printf("hi13");
		    execl(a,a,NULL);
		    //printf("hi14");
		    
    	}
		
		return 0;
	}
	else
	{
		printf("hi2");
		//return 0;
	}
    
}
