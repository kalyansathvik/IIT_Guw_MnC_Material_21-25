#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include<string.h>
#include<stdlib.h>

void fun(int n,int k)
{
	if(n==0)
	{
		printf("100");
	}
	else
	{
	int i=n;
	printf("%d ",i);
	while(i>1)
	{
		if(i%2==0)
		{
			i=i/2;
			
		}
		else
		{
			i=3*i+1;
			
		}
		printf("%d ",i);
	}
	printf("\n");
	}
}

int main(int argc,char* argv[])
{
	if(argc==1)
	fun(100,1);
	
	else
	fun(atoi(argv[1]),1);
	
	//return 0;
}
