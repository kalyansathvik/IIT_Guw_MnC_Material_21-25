#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include<string.h>
#include<stdlib.h>

//int count=0;
void fun(int n)
{
	int i=n;
	printf("%d ",i);
	if(n==0)
	{
		printf("100");
	}
	else
	{
	while(i>1)
	{
		if(i%2==0)
		{
			i=i/2;
			
		}
		else
		{
			i=3*i+1;
			
		}
		printf("%d ",i);
	}
	printf("\n");
	}
	
}


int main(void)
{
	
	while(1)
	{
		char c[255];
		scanf("%s",c);
		if(atoi(c)==1)
		
		break;
		else
		{
			//printf("hi");
			fun(atoi(c));
		}
	}
	//return 0;
}
