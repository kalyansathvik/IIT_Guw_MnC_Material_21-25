#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void fun(int n)
{
	int i=n;
	printf("%d ",i);
	while(i>1)
	{
		if(i%2==0)
		{
			i=i/2;
			
		}
		else
		{
			i=3*i+1;
			
		}
		printf("%d ",i);
	}
	printf("\n");
}

int main(void)
{
	char* c=getenv("n");
	int a[100];
	char temp[100][100]={""};
	int count=0,idk=0;
	for(int i=0;i<strlen(c);i++)
	{
		if((c[i]>='0'&& c[i]<='9'))
		{
			temp[count][idk]=c[i];
			idk++;
		}
		else
		{
			a[count]=atoi(temp[count]);
			
			count++;
			//temp[count]="";
			idk=0;
			//break;
		}
	}
	a[count]=atoi(temp[count]);
	count++;
	//printf("%s",temp);
	
	for(int i=0;i<count;i++)
	{
		fun(a[i]);
	}
	
}
