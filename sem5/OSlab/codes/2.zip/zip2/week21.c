#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include<string.h>
#include<stdlib.h>

void fun(int n)
{
	int i=n;
	printf("%d ",i);
	while(i>1)
	{
		if(i%2==0)
		{
			i=i/2;
			
		}
		else
		{
			i=3*i+1;
			
		}
		printf("%d ",i);
	}
	printf("\n");
}


int main(int argc,char* argv[])
{
	
	if(argc==1)
	{
		fun(100);
	}
	else
	{
		for(int i=1;i<argc;i++)
		{
			int n=atoi(argv[i]);
			fun(n);
		}
	}
}

