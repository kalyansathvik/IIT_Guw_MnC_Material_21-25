
gcc week21.c -o 210123041-q1a
unset n
./210123041-q1a
