#include <sys/types.h>
#include<sys/wait.h>
#include <stdio.h>
#include <unistd.h>
#include<string.h>
#include<stdlib.h>

int main(void)
{
	pid_t pid1=fork();
	if(pid1==0)
	{
		//char* v[]={"week21,10,20,30,40,50,60,70,80,90,NULL"};
		char* env[]={NULL};
		execle("./week21","week21",NULL,env);
		exit(0);
	}
	
	pid_t pid2=fork();
	if(pid2==0)
	{
		//char* v[]={"week21,10,20,30,40,50,60,70,80,90,NULL"};
		char* env[]={NULL};
		execl("./week21","week21","50",NULL);
		exit(0);
	}
	
	
	
}


//pid_t pid3=fork();
	//if
	
