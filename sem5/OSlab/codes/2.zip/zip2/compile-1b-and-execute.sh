gcc week22.c -o 210123041-q1b
unset n
./210123041-q1b
