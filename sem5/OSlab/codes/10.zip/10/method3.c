#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> //Header file for sleep(). man 3 sleep for details. 
#include <pthread.h> 

// A normal C function that is executed as a thread 
// when its name is specified in pthread_create() 

int sud[9][9];
int arr2[27]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};



struct help
{
	int rstart;
	int rend;
	int cstart;
	int cend;
	int arrno;
};

/*
void* rowfun(void* varg)
{
	int e=1;
	for(int i=0;i<9;i++)
	{
		int a[9];
		for(int j=0;j<9;j++)
		{
			a[j]=1;
		}
		
		for(int j=0;j<9;j++)
		{
			a[sud[i][j]-1]=0;
		}
		
		for(int j=0;j<9;j++)
		{
			if(a[j]==1)
			{
				e=0;
			}
		}
	}
	
	if(e==1)
	{
		arr1[0]=1;
	}
}

void* colfun(void* varg)
{
	int e=1;
	for(int i=0;i<9;i++)
	{
		int a[9];
		for(int j=0;j<9;j++)
		{
			a[j]=1;
		}
		
		for(int j=0;j<9;j++)
		{
			a[sud[j][i]-1]=0;
		}
		
		for(int j=0;j<9;j++)
		{
			if(a[j]==1)
			{
				e=0;
			}
		}
	}
	
	if(e==1)
	{
		arr1[1]=1;
	}
}
*/

void* blofun(void* varg)
{
	struct help* h=(struct help*)varg;
	
	int r=0;
	int a[9];
	
	for(int i=0;i<9;i++)
	{
		a[i]=1;
	}
	
	for(int i=(h->rstart);i<=(h->rend);i++)
	{
		for(int j=(h->cstart);j<=(h->cend);j++)
		{
			a[sud[i][j]-1]=0;
		}
	}
	
	for(int i=0;i<9;i++)
	{
		if(a[i]==1)
		{
			r=1;
		}
	}

	if(r==0)
	{
		arr2[h->arrno]=1;
	}
}


int main() 
{ 

	
	FILE* f1=fopen("week10-ML2-input1.txt","r");
	for(int i=0;i<9;i++)
	{
		for(int j=0;j<9;j++)
		{
			fscanf(f1,"%d",&sud[i][j]);
		}
	}
	
	for(int i=0;i<9;i++)
	{
		for(int j=0;j<9;j++)
		{
			printf("%d ",sud[i][j]);
		}
		printf("\n");
	}
	
	/*
	struct help h1;
	h1.rstart=5;
	printf("%d\n",h1.rstart);
	*/
	
	pthread_t thread_id[27]; 
	struct help h1;
	struct help* h;
	h=&h1;
	
	
	int k=0;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			h->rstart=3*i;
			h->rend=(3*i+2);
			h->cstart=3*j;
			h->cend=(3*j+2);
			h->arrno=k;
			
			pthread_create(&(thread_id[k+2]), NULL,blofun,h ); 
			pthread_join(thread_id[k+2], NULL); 
			k++;
			
		}
	}
	
	for(int i=0;i<9;i++)
	{
		h->rstart=i;
		h->rend=i;
		h->cstart=0;
		h->cend=8;
		h->arrno=k;
		
		pthread_create(&(thread_id[k+2]), NULL,blofun,h ); 
		pthread_join(thread_id[k+2], NULL); 
		k++;
		
	}
	
	for(int i=0;i<9;i++)
	{
		h->rstart=0;
		h->rend=8;
		h->cstart=i;
		h->cend=i;
		h->arrno=k;
		
		pthread_create(&(thread_id[k+2]), NULL,blofun,h ); 
		pthread_join(thread_id[k+2], NULL); 
		k++;
		
	}
	
	
	for(int i=0;i<27;i++)
	{
		printf("%d ",arr2[i]);
	}
	
	int w=0;
	
	for(int i=0;i<27;i++)
	{
		if(arr2[i]==0)
		w=1;
	}
	
	if(w==0)
	{
		printf("\nVALID\n");
	}
	else
	{
		printf("\nINVALID\n");
	}
	
	exit(0); 
	
}
