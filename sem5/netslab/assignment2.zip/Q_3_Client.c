//IMPORTANT INSTRUCTIONS
///exit or ctrl+c does the same thing for client: gracefully exit
//THE SERVER SHOULD EXIT WITHIN 5 SECONDS BY TYPING SOMETHING OTHERWISE IT IS ASSUMED HE DOES NOT WANT TO EXIT
//(THIS IS NECESSARY SO THAT WE DONT NEED TO GIVE INPUT TO SERVER EVERYTIME)
//IF A CLIENT WANTS TO DM TYPE "dm{socket_no of receiver} {message}" like "dm4 whatsupp 4" by socket 5 will send socket_no 4 a message "dm from 5: whatsupp 4"
//ALL MESSAGES ARE ASSUMED TO BE BROADCASTED BY DEFAULT

 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include<signal.h>
#define MAX_MESSAGE_LEN 1024

int client_sockety;
char message[MAX_MESSAGE_LEN]="/exit\n";

void *receive_message(void *sock);

void sigint_handler(int signum) {
   // printf("hi2\n");
    send(client_sockety,"/exit\n", strlen("/exit\n"), 0);
    exit(0);
}

int main(int argc,char* argv[]) {

    //provide arguments properly
	if(argc!=3)
	{
		fprintf(stderr,"you are missing some argument or providing additional ones.Provide \n1.filename \n 2.server_ip \n 3.portno\n");
		exit(0);
	}

    
    struct sockaddr_in server_addr;
    
    //create a thread for receiver
    pthread_t recv_thread;

    client_sockety = socket(AF_INET, SOCK_STREAM, 0);
    if (client_sockety < 0) {
        perror("Socket error");
        exit(1);
    }

    //standard setting of server_addr
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(atoi(argv[2]));
    server_addr.sin_addr.s_addr = inet_addr(argv[1]);
    
    

    //connecting client 
    if (connect(client_sockety, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connect error");
        exit(1);
    }

    //handling the created thread
    pthread_create(&recv_thread, NULL, receive_message, &client_sockety);

    while (1) {

        // if (signal(SIGINT, sigint_handler) != SIG_ERR)
        // {
        //     //message[]={'/','e','x','i','t','\n'};
        // }
        // else
        // {
            // fgets(message, sizeof(message), stdin);
        // }

        clock_t start, end;
        double cpu_time_used;

         start=clock();
    // end=clock();
        //printf("hi3\n");
        //if there is signal use sigint_handler
        while((((double)(clock()-start))/(CLOCKS_PER_SEC))<5)
        {
            //end=();
            //printf("hi4\n");
            if(signal(SIGINT, sigint_handler) == SIG_ERR)
            {
                exit(1);
                printf("signal error\n");
            }
            //printf("hi5\n");
        }
        //printf("hi7\n");


        
        fgets(message, sizeof(message), stdin);
        send(client_sockety, message, strlen(message), 0);
        //if the message is /exit then close socket
        if(strcmp(message,"/exit\n")==0)
        {
        memset(message, '\0', sizeof(message));
        break;
        }
    }

    close(client_sockety);
    return 0;
}

void *receive_message(void *sock) {
    int client_socket = *((int *)sock);
    char messag[MAX_MESSAGE_LEN];
    int n;

    
    while (1) {
        //receive message from server
        n = recv(client_socket, messag, sizeof(messag), 0);
        if (n <= 0) {
            //printf("hi1\n");
            close(client_socket);
            return NULL;
            //break;
        }
        messag[n] = '\0';
        //printf("%d\n",client_socket);
        printf("%s", messag);
        //if u get a message like this,it means the server has exited and u should gracefully exit
        if(strncmp(messag,"server exited",strlen("server exited"))==0)
        {
            //printf("hello\n");
            close(client_socket);
            exit(0);
            //return 0;
            return NULL;
            //break;
            
        }
        
    }
    
}

