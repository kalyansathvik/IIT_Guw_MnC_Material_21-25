#include <bits/stdc++.h>
#include <string>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
using namespace std;

class LRUCache
{
public:
    class node
    {
    public:
        string url;
        string data;
        node *prev;
        node *next;
        node(string l, string r)
        {
            url = l;
            data = r;
        }
    };

    node *head = new node("-1", "-1");
    node *tail = new node("-1", "-1");

    int cap;
    unordered_map<string, node *> mp;
    LRUCache()
    {
        cap = 0;
        head->next = tail;
        tail->prev = head;
    }
    LRUCache(int capacity)
    {
        cap = capacity;
        head->next = tail;
        tail->prev = head;
    }

    void addnode(node *first)
    {
        node *t = head->next;
        head->next = first;
        first->prev = head;
        t->prev = first;
        first->next = t;
    }

    void deletenode(node *nod)
    {
        node *delprev = nod->prev;
        node *delnext = nod->next;
        delprev->next = delnext;
        delnext->prev = delprev;
    }

    string get(string url)
    {
        if (mp.find(url) != mp.end())
        {
            node *t = mp[url];
            string ans = t->data;
            mp.erase(url);
            deletenode(t);
            addnode(t);
            mp[url] = head->next;
            return ans;
        }
        return "-1";
    }

    void put(string url, string data)
    {
        if (mp.find(url) != mp.end())
        {
            node *t = mp[url];
            mp.erase(url);
            deletenode(t);
        }
        if (mp.size() == cap)
        {
            node *t = tail->prev;
            mp.erase(t->url);
            deletenode(t);
        }
        addnode(new node(url, data));
        mp[url] = head->next;
    }

    void display()
    {
        node *h = head->next;
        for (int i = 0; i < mp.size(); i++)
        {
            std::cout << i + 1 << "]";
            std::cout << h->url;
            std::cout << "\n";
            h = h->next;
        }
    }
};
class webcache : public LRUCache
{
public:
    using LRUCache::LRUCache;
    void request(string url)
    {
        if (this->get(url) == "-1") // Checking if it already exists in cache
        {
            int i = 0;
            std::string resource = "/";
            std::string hostname = url;

            for (int j = 0; j < url.size(); j++)
            {
                if (url[j] == '/')
                {
                    i = j;
                    break;
                }
            }
            if (i != 0)
            {
                hostname = url.substr(0, i); // Logic to seperate hostname and path of the requested file
                resource = url.substr(i, url.size() - i);
            }
            int clientSocket = socket(AF_INET, SOCK_STREAM, 0); // For HTTP we whould use TCP connection
            if (clientSocket == -1)
            {
                std::cerr << "Error creating socket" << std::endl;
                return;
            }
            struct hostent *server = gethostbyname(hostname.c_str()); // To find out the server IP address of the requested URL
            if (server == nullptr)
            {
                std::cerr << "Error resolving server address" << std::endl;
                return;
            }

            // Configure the server address structure
            struct sockaddr_in serverAddr;
            bzero((char *)&serverAddr, sizeof(serverAddr));
            serverAddr.sin_family = AF_INET;
            int port = 80; // Always use 80 for HTTP
            serverAddr.sin_port = htons(port);
            bcopy((char *)server->h_addr, (char *)&serverAddr.sin_addr.s_addr, server->h_length);

            // Connect to the server
            if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
            {
                std::cerr << "Error connecting to the server" << std::endl;
                return;
            }

            // Sending an HTTP GET request
            std::string getRequest = "GET " + resource + " HTTP/1.1\r\nHost: " + hostname + "\r\nConnection: close\r\n\r\n";
            std::cout << getRequest << endl;
            if (send(clientSocket, getRequest.c_str(), getRequest.size(), 0) == -1)
            {
                std::cerr << "Error sending request" << std::endl;
                return;
            }

            std::string response; // String to store the HTTP response
            char buffer[4096];
            ssize_t bytesRead;

            while ((bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0)) > 0)
            {
                // Append the received data to the response string
                response.append(buffer, bytesRead);
            }

            this->put(url, response); // Add the page to the cache
            std::cout << response;    // Print out the response
            std::cout << "\n\n";
        }
        else
        {
            std::cout << get(url);
            std::cout << "\n\n";
        }
    }
    void contents()
    {
        std::cout << "\n\nCache Contents\n";
        this->display();
        std::cout << "\n\n";
    }
};
int main()
{
    int s;
    std::cout << "Please enter cache size\n";
    std::cin >> s;
    webcache w(s); // Intitate the Cache with the user specified size
    std::string message;
    std::cout << "Enter the url for which you want the content for or type 'exit' to exit the program. Type 'show' to view the contents of the cache.\n";

    std::cin >> message;
    while (message != "exit")
    {
        if (message == "show")
        {
            w.contents(); // To show the contents of cache
        }
        else
        {
            w.request(message); // Send a request for the entered URL
        }
        std::cout << "Enter the url for which you want the content for or type 'exit' to exit the program. Type 'show' to view the contents of the cache.\n";
        std::cin >> message;
    }
    std::cout << "Bye";
    return 0;
}