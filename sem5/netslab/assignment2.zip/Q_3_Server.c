//IMPORTANT INSTRUCTIONS
///exit or ctrl+c does the same thing for client: gracefully exit
//THE SERVER SHOULD EXIT WITHIN 5 SECONDS BY TYPING SOMETHING OTHERWISE IT IS ASSUMED HE DOES NOT WANT TO EXIT
//(THIS IS NECESSARY SO THAT WE DONT NEED TO GIVE INPUT TO SERVER EVERYTIME)
//IF A CLIENT WANTS TO DM TYPE "dm{socket_no of receiver} {message}" like "dm4 whatsupp 4" by socket 5 will send socket_no 4 a message "dm from 5: whatsupp 4"
//ALL MESSAGES ARE ASSUMED TO BE BROADCASTED BY DEFAULT

 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/mman.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>

#define PORT 12345
#define MAX_CLIENTS 10
#define ARRAY_SIZE 10

volatile sig_atomic_t ctrl_c_flag = 0;

void *handle_client(void *arg);

int client_count = 0;
int client_sockets[MAX_CLIENTS]={0,0,0,0,0,0,0,0,0,0};
//int client_sockets[MAX_CLIENTS];
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;



int timedscanf(char* input,int size)
{
    fd_set set;
    struct timeval timeout;
    int rv;

    // Initialize the file descriptor set
    FD_ZERO(&set);
    FD_SET(STDIN_FILENO, &set);  // Add stdin to the set

    // Set the timeout to 5 seconds (5 seconds and 0 microseconds)
    timeout.tv_sec = 5;
    timeout.tv_usec = 0;

    //printf("Enter something within 5 seconds: ");

    // Wait for input from stdin with a timeout
    rv = select(STDIN_FILENO + 1, &set, NULL, NULL, &timeout);

    if (rv == -1) {
        perror("select");  // An error occurred
        //return 1;
    } else if (rv == 0) {
        
        printf("Timed out. No input received within 5 seconds.\n");
        return 1;
        
    } else {
        // Input is available within the timeout period
        //char input[100];
        // if (fgets(input, sizeof(input), stdin) != NULL) {
        //     printf("Input received: %s", input);
        // }
        return 0;
    }

    
}


void print(int a[],int n)
{
    for(int i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");

}

void closeall(int a[],int client_count,int n)
{
    //printf("hi25\n");
    print(a,10);

    for(int i=0;i<client_count;i++)
    {
        if(a[i]>0)
        {   
            printf("%d\n",a[i]);
            if(send(a[i],"server exited so closing you\n",strlen("server exited so closing you\n"),0)>0)
            {
               // printf("hi29\n");
            }
            
            if(close(a[i])!=-1)
            {
                //printf("hi23\n");
            }
        }
    }
}


// int pipe_fd[2]; 
void sigint_handler(int signum) {
    ctrl_c_flag = 1;
    //printf("Ctrl+C received in thread %lu\n", pthread_self());
    closeall(client_sockets,10,6);
    exit(0);
}



int main(int argc,char* argv[]) {
    

   
    int server_socket, new_socket;
    struct sockaddr_in server_addr, new_addr;
    socklen_t addr_size;
    char buffer[1024];
    pthread_t tid;

    //server created
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket error");
        exit(1);
    }
   
   //standard server_addr setting
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(atoi(argv[1]));
    server_addr.sin_addr.s_addr = INADDR_ANY;

    //bind the socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind error");
        exit(1);
    }


    //listen to socket
    if (listen(server_socket, MAX_CLIENTS) == 0) {
        printf("Listening...\n");
        printf("bye\n");
        //fflush(stdout);
    } else {
        printf("Listen error\n");
        exit(1);
    }

    //printf("hi\n");
    
    print(client_sockets,10);
    while (1) {
    
    	//printf("hi2\n");
		
        addr_size = sizeof(new_addr);
        new_socket = accept(server_socket, (struct sockaddr *)&new_addr, &addr_size);
        //dup_clients[++dup_no]=new_socket;
        // printf("dupy %d\n",dup_clients[dup_no-1]);
        // printf("dupy %d\n",dup_clients[dup_no]);
        //printf("hi3\n");

        //mutex locks so that client_sockets is handled by only one thread at a time
        pthread_mutex_lock(&mutex);
        // printf("hi4\n");
        client_sockets[client_count++] = new_socket;
        //munmap(client_sockets, sizeof(int) * ARRAY_SIZE);
        // printf("hi5\n");
        
        pthread_mutex_unlock(&mutex);
        // printf("hi6\n");
		
        //thread creation and error handling
        if(pthread_create(&tid, NULL, &handle_client, &new_socket)<0)
        {
            printf("not able to create thread for %ld",tid);
        }
        // printf("hi7\n");

        print(client_sockets,10);
        // write(pipe_fd[1], client_sockets, sizeof(client_sockets));
        // print(client_sockets,10);
        // close(pipe_fd[1]);
        // print(client_sockets,10);
        

        
    }
    // print(client_sockets,10);
    // write(pipe_fd[1], client_sockets, sizeof(client_sockets));
    // print(client_sockets,10);
    // close(pipe_fd[1]);
    // print(client_sockets,10);
    

}

//function to handle_client that will be executed by a thread
void *handle_client(void *arg) {
    int client_socket = *((int *)arg);
    char buffer[1024];
    int n;
    
   //printf("hi8\n");

    while (1) {

        n = recv(client_socket, buffer, sizeof(buffer), 0);
        if (n <= 0) {
            return NULL;
        }
        buffer[n] = '\0';
        
        print(client_sockets,10);
        //mutually exclude threads from doing the same thing

        pthread_mutex_lock(&mutex);
        //client private messaging other client
    	if(strncmp(buffer,"dm",2)==0)
    	{
    		int receivy=atoi(&buffer[2]);
    		char d[1024]="dm from ";
    		char client_socket_str[10];
    		sprintf(client_socket_str,"%d",client_socket);
    		
    		strcat(d,client_socket_str);
    		strcat(d,":");
    		strcat(d,buffer+3);
    		//printf("this shud be sent:%s",d);
    		//printf("%d",receivy);
    		send(receivy,d,strlen(d),0);
    	}
    	
        //do the same thing for /exit and ctrl+c signal
    	if(strcmp(buffer,"/exit\n")==0 || signal(SIGINT, sigint_handler) == SIG_ERR)
    	{
    		//printf("hi9\n");
    		int j;
            printf("client %d closed\n",client_socket);
            print(client_sockets,10);
    		for(int i=0;i<10;i++)
    		{
    			if(client_sockets[i]==client_socket)
    			{
    				client_sockets[i]=0;
    				j=i;
                    break;
    			}
    			
    		}
            printf("hi10\n");
    		
    		for(int i=(j+1);i<10;i++)
    		{
    			client_sockets[i-1]=client_sockets[i];
    		}
            client_count--;
            print(client_sockets,10);
            //munmap(client_sockets, sizeof(int) * ARRAY_SIZE);
            printf("hi11\n");
            
    	}
        
        //sending normal messages
        if(!(strncmp(buffer,"dm",2)==0))
        {
        char client_socket_str[10];
        sprintf(client_socket_str,"%d",client_socket);
        strcat(client_socket_str,": ");
        //printf("hi14\n");
        print(client_sockets,10);
        //printf("hi15\n");
        for (int i = 0; i < client_count; i++) {
            if (client_sockets[i] != client_socket) {
            	char c[1024];
            	
            	strcpy(c,client_socket_str);
            	strcat(c,buffer);
            	client_sockets[i];
                send(client_sockets[i], c, strlen(c), 0);
            }
        }
        //printf("hi16\n");
        print(client_sockets,10);
        //printf("hi17\n");
       
        // print(client_sockets,10);
        // write(pipe_fd[1], client_sockets, sizeof(client_sockets));
        // print(client_sockets,10);
        // close(pipe_fd[1]);
        // print(client_sockets,10);
        }
        //printf("hi17\n");
        print(client_sockets,10);
        char* buffer;

        // instead of scanf i have used timedscanf so that the server does not need to convey every time that he does not want to exit
        printf("type something in 5 seconds to exit\n");
        int temp=timedscanf(buffer,256);
        
        //printf("%s",buffer);

        // fgets(buffer,sizeof(buffer),stdin);
        if(temp==0)
        {
            // printf("hi30\n");
            // printf("%s",buffer);
            // if(strcmp(buffer,"/exit\n")==0)
            // {
                closeall(client_sockets,10,6);
            //}
        }


        
        pthread_mutex_unlock(&mutex);
    }
    //closing the client socket
    close(client_socket);
    //printf("hi12\n");
}

