#include <iostream>
#include <list>
#include <string>
#include <queue>
#include <algorithm> // max
#include <cmath>
#include <math.h>
#include <random> // for hooman random stuff



//changes that can be made
// 1.change the includes
// 2.change the way the functions that use random values
// 3.change how input is taken
//4.change the constant values to 802.11n standard
//5.backoff values repeat avvaddu ani ta annadu anta kani adhi em akkarledu

int time1=0;
int time2=0;


std::mt19937 gen(42);
std::mt19937 rgen(42);


const long double maxRTM = 3;              // max no of retransmissions
const long long int maxPktSize = 1544;          // max size of a packet in bytes
const long long int ackPktSize = 64;            // acknowledgement packet size in bytes
const long double channelCapacity = 11000000.0;    // 11 Mbps (bits)
const long double SIFS = 0.00005;                  // 0.05 msec, delay before ack(the Short InterFrame Space)
const long double DIFS = 0.0001;                   // 0.1 msec, delay before send(the Distributed Coordination function INterframe space)
const long double SYNC = 0.00001;                  // 0.01 msec
bool channelBusy = false;

long double lambda=0.01;
long long int N = 20;             // no of hosts in network.
long long int T = 400;            // max backoff value in no of sync cycles. Should be larger than N I suppose.
long double TO = 0.005;           //TimeOUt values 
long long int eventsSimulated = 1000000; // the bound of for loop

long double nedt(long double lambda)
{
    std::uniform_real_distribution<> dist(0, 1); 
    long double u = dist(gen);
    return ((-1/lambda)*std::log(u));
}


long double dataLengthFrame(long double rate) 
{
    std::exponential_distribution<> d(1);

    return (long long int)(maxPktSize * d(gen));
}


// generate a random backoff value less than or equal to T 
long long int generateRandomBackOff(long long int T, const long long int backoff[], long long int N)
{
   
    
    std::uniform_int_distribution<long long int> idist(1, T); 
    
    long long int rd = idist(rgen);

   
    return rd;
}

long long int randomDestination(long long int source, long long int N)
{
    std::uniform_int_distribution<long long int> idist(0, N - 1); //(inclusive, inclusive)
    
    long long int rd = idist(rgen);
    // if random destination and source are same, recursively call the function
    if (rd == source) {
        rd = randomDestination(source, N);
    }
   
    return rd;
}

enum eventtype {
    arrival, departure, sync, timeout
};


class Event {

public:
    long double eventTime;
    eventtype type;
	Event(eventtype type, long double etime):  type(type),eventTime(etime) {}
    virtual ~Event(){}


};

class Arrival: public Event {
    
public:
    

    long long int host;

    Arrival(long double stime, long long int h): Event(arrival, stime + nedt(lambda)), host(h) {}

    static void setLambda(long double l)
    {
        lambda = l;
    }

    

};

// long double Arrival::lambda = 0;

class Departure: public Event {

   
public:
     // shape of packet size distribution
    static long double mu;

    bool ack;         // denotes if it is an acknowedgement packet
    long long int source;         // source host
    long long int destination;    // destination host
    long long int packetID;       // id of packet, see host class
    long long int size;           // paket size in bytes, used to determine throughput

    Departure(long double stime, long long int s, long long int d, long long int id, bool a): Event(departure, stime), ack(a), source(s), destination(d), packetID(id) 
    {
        // if ack packet, set the time to be that size
        // time already current time, so just need to add the new time.
        if(ack)
        {
                size = ackPktSize;
                eventTime += (SIFS + size*8/channelCapacity);
        }
        else
        {
                size = dataLengthFrame(mu);
                eventTime += (DIFS + size*8/channelCapacity);
            

        }
        

    }

    static void setMu(long double m)
    {
        mu = m;
    }

   
};

long double Departure::mu = 0;

class Sync: public Event {

    static long double SYNC;

public:
    Sync(long double stime): Event(sync, stime + SYNC) {}

    static void setSYNC(long double s)
    {
        SYNC = s;
    }

};

long double Sync::SYNC = 0;

class Timeout: public Event{

    
public:

    static long double to_time;

    long long int host;
    long long int timeoutID;

    Timeout(long double stime, long long int h, long long int id): Event(timeout, stime + to_time), host(h), timeoutID(id) {}

    static void setTO(long double t)
    {
        to_time = t;
    }

};

long double Timeout::to_time = 0;

class GEL { // Global Event List

	std::list<Event*> GlobalEventList;

public:
	GEL() {
        GlobalEventList = std::list<Event*>(); // this line may not be necessary, but oh well
    }

    //if its the first event just push it
	void insert(Event *event) {
		if (GlobalEventList.size() == 0) {
            GlobalEventList.push_front(event);
            return;
        }

    //else insert it in to the list such that the list such that they are in ascending order of event times
		for (std::list<Event*>::iterator itr = GlobalEventList.begin(); itr != GlobalEventList.end(); itr++) {
			if ((*(*itr)).eventTime > (*event).eventTime) {
                GlobalEventList.insert(itr, event);
                return;
            }
        }

        GlobalEventList.push_back(event);
	

	} // insert sorted by events time

	Event* removeFirst() {

		Event *firstElement = GlobalEventList.front();
		GlobalEventList.pop_front();

		return firstElement;
	}
};

// not sure i need all this stuff yet
class Packet {
    long long int destination;
    bool isAck; // true acknowledgement, false datapacket
    long long int  ackID; // used to make sure ack makes sense and stuff
    long double queueTime; // time when packet first queued, used for statistics (Network delay)


    friend class Host;

public:
    Packet(long double t, long long int dest, bool ack, long long int id = 0): destination(dest), isAck(ack), ackID(id), queueTime(t){}


};

class Host { 
    
public:
    static long long int NumHosts; // need to know this in order to create random destination
    static long long int T;        // max backoff given no retransmissions
    // static array so we can implement collision avoidance
    static long long int* backoff; // doing it in syc tics versus real time because easier for conflict avoidance
    // backoff < 0 means nothing to transmit
    // backoff > 0 means waiting to transmit
    // backoff == 0 means either transmitting or waiting for ack
 
    long long int packetID; // the no of the packet sent.  
   
    long long int droppedPackets; 
    long long int hostID;  // position in hosts array, maybe don't need this, but might if put create packets and stuff
    long long int tmNum; // transmission no, max tmNum = 1 + maxRTM.  Max backoff = tmNum * T
    std::vector<long long int> vtmNum;

    long double retransmitTime; // used to calculate delay when there has been a retransmission
    long double delay;  // total delay, used for statistics.
    std::queue<Packet> packetQueue; // i think its initialized implicitly

    // initially set backoff to (-1) to show that nothing in queue
    Host(long long int id): packetID(0), droppedPackets(0),  hostID(id), tmNum(0), retransmitTime(0), delay(0){
        backoff[id] = -1;
    }

    // initialize static variables
    static void initHosts(long long int N, long long int t)
    {
        NumHosts = N;
        backoff = new long long int[N];
        T = t;
    }

    void enqueueDataPacket(long double stime)
    {
        packetQueue.push(Packet(stime, randomDestination(hostID, NumHosts), false));
        // if nothing ready to transmit, as denoted by a negative backoff value
        // then need to set a new backoff value for this packet.
        
        if (backoff[hostID] < 0)
            backoff[hostID] = generateRandomBackOff(T, backoff, NumHosts);
    }
    void enqueueAckPacket(long double stime, long long int dest, long long int ackID)
    {

        packetQueue.push(Packet(stime, dest, true, ackID));
        // if nothing ready to transmit, as denoted by a negative backoff value
        // then need to set a new backoff value for this packet
        if (backoff[hostID] < 0)
            backoff[hostID] = generateRandomBackOff(T, backoff, NumHosts);

    }

    // decrements backoff value if it is larger than zero
    // returns true if this act makes the value 0, and thus the Host is ready to transmit
    bool decrementBackoff()
    {
        if (backoff[hostID] > 0)
        {
            --(backoff[hostID]);
            if(backoff[hostID] == 0)
                return true;
        }
        return false;
    }


    void receiveAck(long long int AckID)
    {
        // if correct ack, can pop packet from start of queue
        if (AckID == packetID)
        {
            packetQueue.pop(); // pop packet from queue
            
            packetID++; // new packet to send, so increment packetID
            vtmNum.push_back(tmNum);
            tmNum = 0; // need to reset TmNum because new packet to transmit.
            // if no more packets in queue, indicate it by setting backoff id to -1
            if (packetQueue.empty())
            {
                backoff[hostID] = -1;
            }
            // else if still packet to send, set new backoff value
            else
            {
                backoff[hostID] = generateRandomBackOff(T, backoff, NumHosts);
            }


        } 
        // if AckID does not match PacketID do nothing
        // should never get out of order ack because can only sent 1 packet at a time
    }

    void receiveTimeout(long double stime, long long int TO_ID)
    {
        // if timeout refers to current packet, need to resend with larger backoff
        time1++;
        if (TO_ID == packetID)
        {
            // if haven't reached max transmissions yet, need to retransmit it by resetting backoff value
            // tmNum refers to current transmission.  On transmission 3, there have been 2 retransmissions
            // if MaxRTM = 3, then should be able to send another one.
            // if MaxRTM = 3 and tmNum = 4, then there have already been 3 retransmissions and need to abort
            if (tmNum <= maxRTM)
            {
                retransmitTime = stime;

                backoff[hostID] = generateRandomBackOff(T * (tmNum + 1), backoff, NumHosts);
            }
            // else need to drop packet.  Do this by pretending to ack it
            else
            {
                droppedPackets++;
                receiveAck(packetID);

            }

        }

    }


    // performs packet processing and prepares packet for departure
    // returns a departure event 
    Departure* createDeparture(long double stime)
    {
         
        Packet p = packetQueue.front();

        Departure* depart;

        int j=0;
        if (p.isAck)
        {
            receiveAck(packetID);
            depart =  new Departure(stime, hostID, p.destination, p.ackID, true);
        }
        // else need to create packet and increment tmNum
        else
        {
            depart = new Departure(stime, hostID, p.destination, packetID, false);
            tmNum ++;
            j=1;

        }

        // calculate delay
        // if this is a retransmission (tmNum > 1), then need to use retransmitTime as a base
        if (tmNum > 1)
        {
            delay += ((*depart).eventTime - retransmitTime);
        }
        // else use packet time as a base
        else
        {
            delay += ((*depart).eventTime- p.queueTime);
        }

        if(j==1)
        std::cout<<"Node "<<depart->source<<" sent message to "<<depart->destination<<"\n";
        else
        std::cout<<"Node "<<depart->source<<" sent acknowledgement to "<<depart->destination<<"\n";
        return depart;

    }

    Timeout* createTimeout(long double stime)
    {
        time2++;
        return new Timeout(stime, hostID, packetID);
    }
    
};

long long int* Host::backoff = NULL;
long long int Host::NumHosts = 0;
long long int Host::T = 0;

int main(int argc, char const *argv[])
{


    //  these are variables used throught the program
    long double time = 0;        // time simulated since start of simulation in seconds
    long double transmitted = 0; // no of bytes successfully transmitted (will include ack bytes)
    long double delay = 0;       // queue + transmission delay in seconds
    long long int packets = 0;
    

    std::cout<<"Description:\nPackets arrive at hosts in exponential distribution with mean lambda="<<lambda<<"\n"
            <<"size of packets roughly follows geometric distribution with p="
             <<"max no of retransmissions=3\n"
             <<"max packet size=1544 bytes\n"
             <<"ACK packet size(it is always a constant)=64\n"
             <<"Channel capacity=10Mbps"
             <<"SIFS=50 microseconds"
             <<"DIFS=100 microseconds"
             <<"SYNC=10 microseconds "
             <<"TimeOut value=5 milliseconds"
             <<"no of hosts in the network(N)=20\n"
             <<"Maximum backoff value in SYNC cycles(T)=400\n";
                
    std::cout<<"If you want to change:\n";
    std::cout<<"N:";
    std::cin>>N;
    std::cout<<"T:";
    std::cin>>T;
    std::cout<<"lambda:";
    std::cin>>lambda;
    std::cout<<"\n";

    Host** hosts; // an array of host pointers
    GEL* eventList; // holds list of events

    hosts = new Host*[N];           // create an array to hold all Hosts
    eventList = new GEL();          // create a list of events
    Event* e;                       // holds the event currently being manipulated

    // initialize static variables of events
  
    Sync::setSYNC(SYNC);
    Host::initHosts(N, T);
    Timeout::setTO(TO);


    // initialize each host and create its initial arrival event
    for (long long int i = 0; i < N; i++)
    {
        hosts[i] = new Host(i);
        (*eventList).insert(new Arrival(time, i));

    }

    (*eventList).insert(new Sync(time));  // create the first sync event


    for(long long int i = 0; i < eventsSimulated; i++)
    {
        // pop event to handle
        e = (*eventList).removeFirst();

        // update time
        time = (*e).eventTime;

        if ((*e).type == arrival)
        {
            // cast to arrival poinhter
            Arrival *a = static_cast<Arrival*>(e);

            // need to create a new arrival event for the previous arrival event's host
            eventList->insert(new Arrival(time, (*a).host));

            

            // now need to put packet in queue of host.
            // will generate length of packet on demand when create a departure event
            // but need to indicate that it is not a ack packet
            hosts[(*a).host]->enqueueDataPacket(time);

        }

        
        else if ((*e).type == departure)
        {
            // cast to departure pointer
            Departure *d = static_cast<Departure*>(e);

            
            // keep track of bytes transmitted
            transmitted += (*d).size;
            packets ++;


            // if an ack departure, need to notify receiving host
            if (((*d).ack))
            {
                // using an long long integer for packet IDs
                hosts[(*d).destination]->receiveAck((*d).packetID);

            }
            // if a data departure, need to create ack packet in destination queue
            else
            {
                hosts[(*d).destination]->enqueueAckPacket(time, (*d).source,(*d).packetID);
            }
            // set channel to free
            channelBusy = false;

        }
        else if ((*e).type == sync)
        {
            
            Sync *s = static_cast<Sync*>(e);

            // need to create a new Sync event
            eventList->insert(new Sync(time));

            // if channel is free, go through all hosts and decrement backoff.
            // if backoff reaches zero, set channel to busy and create departure event
            // also continue to decrement the rest of the backoffs to help with collision avoidance
            if (channelBusy == false)
            {
                // possible host that needs to transmit
                long long int hostToProcess = -1;
                for (long long int i = 0; i < N; i++)
                {
                    // decrements backoff value, returns true if backoff becomes zero
                    // need to save host index if it needs to be processed
                    // since we provide collision detection, there should only ever be one host ready to process
                    if(hosts[i]->decrementBackoff())
                    {
                        hostToProcess = i;
                    }

                }

                // if a host was selected to process, need to process it

                if (hostToProcess >= 0)
                {
                    // have the host create a departure event
                    // std::cout<<"Node "<<hostToProcess<<" is transmitting\n";
                    Departure* departHelp = (hosts[hostToProcess]->createDeparture(time));
                    // std::cout<<"Node "<<departHelp<<" is transmitting\n"<<;
                 
                    eventList->insert(departHelp);
                    // create a timeout event tied to the host, but only if not ack
                    if (!(*departHelp).ack)
                    {
                        eventList->insert(hosts[hostToProcess]->createTimeout(time));

                    }
                    // set channel to busy
                    channelBusy = true;
                   
                }
            }


            }
            
        
        else if ((*e).type == timeout)
        {
            // cast to arrival pointer
            Timeout *t = static_cast<Timeout*>(e);

            // tell host that timeout event occured
            hosts[(*t).host]->receiveTimeout(time, (*t).timeoutID);

        }

        // free memory of processed event
        delete e;


    }

    std::cout<<"\n";
    long long int drop = 0;
    long long int collisions=0;
    long long summy=0;
    for (long long int i = 0; i < N; i++)
    {
        long long int sum_tmNum=0;
        delay += (*hosts[i]).delay;
        drop += (*hosts[i]).droppedPackets;
        
        long long size_of_vtmNum=((*hosts[i]).vtmNum).size();
        if(size_of_vtmNum>0)
        {
            std::cout<<"Node "<<i<<" has sent "<<size_of_vtmNum<<" packets which have backed off";
            for(int j=0;j<size_of_vtmNum;j++)
            {
                std::cout<<" "<<((*hosts[i]).vtmNum)[j]<<" ";
                sum_tmNum+=((*hosts[i]).vtmNum)[j];
            }
            std::cout<<" times respectively\n";
        }
        summy+=sum_tmNum;
        
       
    }


   
    std::cout << "\nPackets Dropped(because they have exceeded the max retransmission no): " << drop << std::endl;
    std::cout << "No of successful transmissions: " << packets << std::endl;
    std::cout << "Total no of collisions experienced by all nodes together: "<<summy<<"\n";
    std::cout<<"avg no of collisions a packet has experienced before it was sent/dropped: "<<(summy/(long double)packets)<<"\n";

    std::cout << "Throughput: " << transmitted / time << " Bps" << std::endl;
    std::cout << "Average Network Delay: " << delay / transmitted << " s/B" << std::endl; 
    // std::cout<<"time1"<<time1<<"\n";
    // std::cout<<"time2"<<time2<<"\n";

    
    std::cout << "------------------------------------------------------" << std::endl;

    // delete dynamically allocated data
    for (long long int i = 0; i < N; i++)
    {
        delete hosts[i];
    }
    delete hosts;
    delete eventList;

}