#include <bits/stdc++.h> 

class Router { 
public: 
    int router_id; //Unique ID
    std::map<Router *,int>neighbours;
    std::map<int, std::pair<int,int>>routing_table;//Stores destination, cost to reach destination, next router to reach 
    
    Router(int x)
    {
        router_id = x;
    }
    void add_neighbour(Router* neighbour, int edge_cost)
    {
        std::pair<Router *,int> r;
        neighbours[neighbour] = edge_cost;
        routing_table[neighbour->router_id] = std::make_pair(edge_cost,neighbour->router_id);
        return;
    } 
    void update_routing_table(std::vector<Router *> all_routers)
    {
        //Dijkstra's Algorithm
        std::priority_queue<std::pair<int,Router*>, std::vector<std::pair<int,Router*>>, std::greater<std::pair<int,Router*>> >
        pq;
 
        
        std::map<int,int> dist;
        std::map<int, int>prev;
        std::map<int,int>next_hop;
        for(int i = 0;i < all_routers.size();i++)
        {
            dist[all_routers[i]->router_id] = 10000;
            prev[all_routers[i]->router_id] = this->router_id;
        }
        pq.push(std::make_pair(0, this));
        dist[this->router_id] = 0;
        prev[this->router_id] = this->router_id;
        next_hop[this->router_id] = this->router_id;
        
        while (!pq.empty()) {
           
            Router* u = pq.top().second;
            pq.pop();
    
            
        
            for (auto i = u->neighbours.begin(); i != u->neighbours.end(); i++) {
                
                int v = i->first->router_id;
                int weight = i->second;
    
                if (dist[v] > dist[u->router_id] + weight) {
                    dist[v] = dist[u->router_id] + weight;
                    prev[v] = u->router_id;
                    pq.push(std::make_pair(dist[v], i->first));
                }
            }
        }
        //To find next hop
        for(auto i = dist.begin();i != dist.end();i++)
        {
            
            int h = i->first;
            while(prev[h] != this->router_id)
            {
                h = prev[h];
            }
            next_hop[i->first] = h;
            routing_table[i->first] = std::make_pair(i->second,h);
        }
    
    }
    void print_routing_table()
    {
        for(auto i : routing_table)
        {
            std::cout << i.first << "\t\t" << i.second.first << "\t\t" << i.second.second << std::endl;
        }
    }
}; 

void simulate_routing(Router* source,Router* destination,std::vector<Router*>all_routers)
{
    std::string path = std::to_string(source->router_id);
    int cost_incurred = 0;
    while(source != destination)
    {
        int next = source->routing_table[destination->router_id].second;
        
        path = path + "->" + std::to_string(next);
        for(auto i:all_routers)
        {
            if(i->router_id == next)
            {
                cost_incurred = cost_incurred + source->neighbours[i];
                std::cout << "Going from Router : " << source->router_id << " to Router : " << i->router_id << std::endl;
                source = i;
            }
        }

    }
    std::cout << "Destination reached!" << std::endl;
    std::cout << "Path Taken : " << path << std::endl;
    std::cout << "Cost Incurred : " << cost_incurred << std::endl;

}
//To add a link between x and y with cost c
void add_link(Router*x,Router* y,int c)
{
    x->add_neighbour(y,c);
    y->add_neighbour(x,c);
}
int main() 
{ 
    std::vector<Router*>all_routers;
    Router r0 = Router(0);
    Router r1 = Router(1);
    Router r2 = Router(2);
    Router r3 = Router(3);
    Router r4 = Router(4);
    Router r5 = Router(5);
    Router r6 = Router(6);
    all_routers.push_back(&r0);
    all_routers.push_back(&r1);
    all_routers.push_back(&r2);
    all_routers.push_back(&r3);
    all_routers.push_back(&r4);
    all_routers.push_back(&r5);
    all_routers.push_back(&r6);
   
    add_link(&r0,&r1,2);
    add_link(&r0,&r2,6);
    add_link(&r2,&r3,8);
    add_link(&r1,&r3,5);
    add_link(&r3,&r4,10);
    add_link(&r3,&r5,15);
    add_link(&r4,&r6,2);
    add_link(&r5,&r6,6);
    r0.update_routing_table(all_routers);
    r1.update_routing_table(all_routers);
    r2.update_routing_table(all_routers);
    r3.update_routing_table(all_routers);
    r4.update_routing_table(all_routers);
    r5.update_routing_table(all_routers);
    r6.update_routing_table(all_routers);

    
    
    simulate_routing(&r0,&r6,all_routers);
    return 0; 
}