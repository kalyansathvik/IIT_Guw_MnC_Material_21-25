// Server side implementation of UDP client-server model 
#include <bits/stdc++.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h>
#include <ctime> 
#include <iostream> 


#define PORT	 8080 
#define MAXLINE 1024 

using namespace std;

struct Packet {
    int seqNum;
    // char data[MAXLINE];
    // char data;
    int data;
	int ack;
	int checksum;
};

// Driver code 
int main() {
    struct Packet packet;
	int sockfd; 
	// char buffer[MAXLINE]; 
	// const char *hello = "Hello from server"; 
	struct sockaddr_in servaddr, cliaddr; 
	
	// Creating socket file descriptor 
	if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
		perror("socket creation failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	// memset(&servaddr, 0, sizeof(servaddr)); 
	// memset(&cliaddr, 0, sizeof(cliaddr)); 
	
	// Filling server information 
	servaddr.sin_family = AF_INET; // IPv4 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT); 
	
	// Bind the socket with the server address 
	if ( bind(sockfd, (const struct sockaddr *)&servaddr, 
			sizeof(servaddr)) < 0 ) 
	{ 
		perror("bind failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	socklen_t len;
    int n; 

	len = sizeof(cliaddr); //len is value/result 
    int windowSize;
    recvfrom(sockfd, &windowSize, sizeof(windowSize), 0,
             (struct sockaddr*)&cliaddr, &len);

	// n = recvfrom(sockfd, &packet, sizeof(packet), 0,( struct sockaddr *) &cliaddr, 
	// 			&len); 
    int w=0;
	int i=0;
	bool w4=0;
	int timeout;
    while(w<=windowSize){
        recvfrom(sockfd, &packet, sizeof(packet), 0,( struct sockaddr *) &cliaddr, 
                    &len); 
        // buffer[n] = '\0';
		Packet pac;

		if(w==3&&!w4){
			w4=1;
			// pac.ack=ack;
			printf("Packet received : %d\n", packet.data);
			cout<<"		corrupted data"<<endl;
			pac.checksum=1;
			sendto(sockfd, &pac, sizeof(pac), 
			0, (const struct sockaddr *) &cliaddr, 
				len);
		}
		else{
			int rec=rand()%2;	//rec==1 means packet lost
			// cout<<+rec<<endll;
			if(rec){
				// timeout=1;
					time_t time_req;

			// Without using pow function
			time_req = time(NULL);
				cout<<"		Packet lost"<<endl;
				sleep(3);
				// cout<<time_req - time(NULL)<<endl;
				int ack=-1;
				pac.ack=ack;
				pac.checksum=0;
				sendto(sockfd, &pac, sizeof(pac), 
            0, (const struct sockaddr *) &cliaddr, 
					len);

				continue;
			}
			
			printf("Packet received : %d\n", packet.data);

			int ackNum=packet.seqNum;
			if(i!=ackNum){
				w--;
				cout<<"		Duplicate packet, reacknowledging"<<endl;
				i=ackNum;
			}
			w++;
			rec= rand()%2;
			if(rec){
				sleep(3);
			}
			pac.ack=ackNum;
			pac.checksum=0;
			sendto(sockfd, &pac, sizeof(pac), 
            0, (const struct sockaddr *) &cliaddr, 
					len); 
			std::cout<<"Ack sent "<<ackNum<<"\n"<<std::endl;
			i=(i+1)%2;
		}
    }
	close(sockfd);
	return 0; 
}