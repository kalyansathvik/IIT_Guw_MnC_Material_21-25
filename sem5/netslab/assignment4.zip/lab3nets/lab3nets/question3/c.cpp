// Client side implementation of UDP client-server model 
#include <bits/stdc++.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include <ctime>
#include <iostream> 


using namespace std;

#define PORT	 8080 
#define MAXLINE 1024 

struct Packet {
    int seqNum;
    // char data[MAXLINE];
    // char data;
    int data;
    int ack;
    int checksum;
};
// Driver code 
int main() {
    int windowSize;
    int timeout=2;
    cout<<"Enter the window size: ";
    cin>>windowSize;
    int w=1;
	int sockfd; 
	char buffer[MAXLINE]; 
	// const char *hello = "Hello from client"; 
	struct sockaddr_in	 servaddr; 

	// Creating socket file descriptor 
	if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
		perror("socket creation failed"); 
		exit(EXIT_FAILURE); 
	} 

	// memset(&servaddr, 0, sizeof(servaddr)); 
	
	// Filling server information 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_port = htons(PORT); 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	
	int n;
	socklen_t len;

    sendto(sockfd, &windowSize, sizeof(windowSize), 0,
           (const struct sockaddr*)&servaddr, sizeof(servaddr));
    struct Packet packet;
	int i=0;
    while(w<=windowSize){
        packet.seqNum=i;
        packet.data=w;
        packet.checksum=0;
        w++;
        time_t time_req;

	    // Without using pow function
	    time_req = time(NULL);

        sendto(sockfd, &packet, sizeof(packet), 
            0, (const struct sockaddr *) &servaddr, 
                sizeof(servaddr)); 
        std::cout<<"Sent seq num :"<<i<<endl; 
        
        // int ackNum;
        Packet pac;
        n = recvfrom(sockfd, &pac, sizeof(pac), 
            0, (struct sockaddr *) &servaddr, 
                    &len);

        if(pac.checksum){
            cout<<"                 courrupted"<<endl;
            cout<<"     Retransmitting"<<endl;
            w--;
            continue;
        }
        time_req = time(NULL) - time_req;
        // buffer[n] = '\0'; 
        int ackNum= pac.ack;
        if(time_req>timeout){
            w--;
            if(ackNum==packet.seqNum) cout<<"           Acknowledgement lost"<<endl;
            cout<<"     Timeout"<<endl;
            cout<<"     Retransmitting"<<endl;
            continue;
        }
        std::cout<<"Received Ack num :"<<ackNum<<std::endl; 
        cout<<"\n____________________________________________________________\n"<<endl;
        i=(i+1)%2;
    }
	cout<<"BYE :)"<<endl;

	close(sockfd); 
	return 0; 
}