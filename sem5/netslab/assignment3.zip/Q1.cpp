#include<iostream>
#include<string>
#include<queue>
#include<map>
#include<set>

using namespace std;

class HttpRequest{
    public:
    int ID;
    int websiteID;
    int processing_time;
    HttpRequest(int website_id){
        this->ID=rand();
        this->websiteID=website_id;
        this->processing_time=1;
    }
};

class Website{
    private:
    int ID;
    string ownerID;
    queue<HttpRequest> request_Queue_;
    public:
    Website(){}
    Website(int website_id, string owner_id){
        this->ID=website_id;
        this->ownerID=owner_id;
    }
    void add_request(HttpRequest http_request){
        request_Queue_.push(http_request);
    }
    void handle_request(){
        if(request_Queue_.size()>0){
            request_Queue_.pop();
            cout<<ownerID<<" ";
        }
    }
};


class LoadBalancer{
    private:
    map<int, Website> map_of_website_;
    set< tuple<int,int,int>, greater<tuple<int,int,int> > > order_of_website_;
    public:
    void add_website(int website_id, string owner_id, int bandwidth, int processing_power){
        Website WEB(website_id, owner_id);
        map_of_website_[website_id]=WEB;
        order_of_website_.insert(make_tuple(bandwidth, processing_power, website_id));
    }
    void enqueue_request(HttpRequest http_request){
        map_of_website_[http_request.websiteID].add_request(http_request);
    } 
    void dequeue_requests(){
        for(auto x : order_of_website_){
            map_of_website_[get<2>(x)].handle_request();
        }
    }
};

void _Test_Case1(){
    LoadBalancer T_1;
    T_1.add_website(1, "AMAZON", 500, 100);
    T_1.add_website(2, "FLIPKART", 500, 100);
    T_1.enqueue_request(HttpRequest(1));
    T_1.enqueue_request(HttpRequest(2));
    T_1.enqueue_request(HttpRequest(2));
    T_1.enqueue_request(HttpRequest(1));
    T_1.enqueue_request(HttpRequest(1));
    T_1.enqueue_request(HttpRequest(2));
    T_1.enqueue_request(HttpRequest(1));
    for (int i = 0; i < 7; i++)
        T_1.dequeue_requests();
}

void _Test_Case2(){
    LoadBalancer T_2;
    int l=1000;
    for(int i=0;i<7;i++)
    {
        string s="website";
        s+=to_string(i);
        T_2.add_website(i, s, l, 100); 
        l-=100;   
    }
    for (int i = 0; i < 20; i++)
        T_2.enqueue_request(HttpRequest(rand()%7));
    for (int i = 0; i < 20; i++)
        T_2.dequeue_requests();
}

void _Test_Case3(){
    LoadBalancer T_3;
    int l=1000;
    for(int i=0;i<7;i++)
    {
        string s="website";
        s+=to_string(i);
        T_3.add_website(i, s, 100, l); 
        l-=100;   
    }
    for (int i = 0; i < 20; i++)
        T_3.enqueue_request(HttpRequest(rand()%7));
    for (int i = 0; i < 20; i++)
        T_3.dequeue_requests();
}

void _Test_Case4(){
    LoadBalancer T_4;
    for(int i=0;i<7;i++)
    {
        string s="website";
        s+=to_string(i);
        T_4.add_website(i, s, 2576, 100);
    }
    for (int i = 0; i < 20; i++)
        T_4.enqueue_request(HttpRequest(rand()%7));
    for (int i = 0; i < 20; i++)
        T_4.dequeue_requests();
}

void _Test_Case5(){
    LoadBalancer T_5;
    for(int i=0;i<7;i++)
    {
        string s="website";
        s+=to_string(i);
        T_5.add_website(i, s, 2576, 100);
    }
    for(int i=0; i<7; i++)
    {
        for (int j = 0; j < 20; j++)
            T_5.enqueue_request(HttpRequest(i));
    }
    for (int i = 0; i < 140; i++)
        T_5.dequeue_requests();
}

void _Test_Case6(){
    LoadBalancer T_6;
    for(int i=0;i<7;i++)
    {
        string s="website";
        s+=to_string(i);
        T_6.add_website(i, s, 2576, 100); 
    }
    for (int i = 0; i < 10; i++)
        T_6.dequeue_requests();
}

void _Test_Case7(){
    LoadBalancer T_7;
    T_7.add_website(0, "website0", 700, 100);
    T_7.add_website(1, "website1", 100, 600);
    T_7.add_website(2, "website2", 200, 900);
    T_7.add_website(3, "website3", 500, 700);
    T_7.add_website(4, "website4", 300, 400);
    T_7.add_website(5, "website5", 900, 800);
    T_7.add_website(6, "website6", 200, 500);
    for (int i = 0; i < 20; i++)
        T_7.enqueue_request(HttpRequest(rand()%7));
    for (int i = 0; i < 20; i++)
        T_7.dequeue_requests();
}

void _Test_Case8(){
    LoadBalancer T_8;
    T_8.add_website(1849, "AMAZON", 2576, 100);
    for (int i = 0; i < 10; i++)
        T_8.enqueue_request(HttpRequest(1849));
    for (int i = 0; i < 10; i++)
        T_8.dequeue_requests();
}

int main(){
    printf("Test Case 1: Basic Load Balancing\n");
    printf("\n\n");
    _Test_Case1();
    printf("\n\n");
    printf("Test Case 2: Differential Bandwidth Allocation\n");
    printf("\n\n");
    _Test_Case2();
    printf("\n\n");
    printf("Test Case 3: Differential Processing Power Allocation\n");
    printf("\n\n");
    _Test_Case3();
    printf("\n\n");
    printf("Test Case 4: Equal Allocations\n");
    printf("\n\n");
    _Test_Case4();
    printf("\n\n");
    printf("Test Case 5: Large Number of Requests\n");
    printf("\n\n");
    _Test_Case5();
    printf("\n\n");
    printf("Test Case 6: Empty Queues\n");
    printf("\n\n");
    _Test_Case6();
    printf("\n\n");
    printf("Test Case 7: Unequal Bandwidth and Processing Power\n");
    printf("\n\n");
    _Test_Case7();
    printf("\n\n");
    printf("Test Case 8: Edge Case - Single Website\n");
    printf("\n\n");
    _Test_Case8();
    printf("\n\n");
    return 0;
}