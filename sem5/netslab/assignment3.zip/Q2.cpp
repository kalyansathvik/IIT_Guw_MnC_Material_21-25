#include<bits/stdc++.h>
#include <stdio.h>              // Needed for printf()
#include <stdlib.h>             // Needed for exit() and rand()
#include <math.h>               // Needed for log()
using namespace std;
class customer{
    public:
        int cust_id;
        double time;
        bool completed;
        double waiting_time;
        double arrival_time;
        int serv_no;

};
struct comp
{
    bool operator ()( const customer &p1, 
                      const customer &p2 ) const
    {
        return ( p1.time  < p2.time );
    }
};

double rand_val(int seed);      // RNG for unif(0,1)
double exponential(double x);   // Generate exponential RV with mean x
bool check(bool* busy, int size);

int main()
{
    cout << "\t\tAirport Queue Simulation\t\t" << endl; 
    rand_val(1);
    int numofserv;
    cout << "Please enter number of servers:" << endl;
    cin >> numofserv;
    int waiting = 0;
    int buf_size = 1000;
    cout << "Please enter queue length:" << endl;
    cin >> buf_size;
    double lamda;
    double mu;
    cout << "Please enter arrival rate" << endl;
    cin >> lamda;
    cout << "Please enter service rate" << endl;
    cin >> mu;
    int completions = 0;
    set<customer,comp>Pass;
    queue<customer>wait;
    int N = 100000;
    customer c[N];
    bool busy[numofserv];
    int lc = 0;
    
    double last_busy[numofserv];
    double total_busy[numofserv];
    double total_time;
    double t = 0;
    for(int i = 0;i < N;i++)
    {
        c[i].cust_id = i+1;
        c[i].completed = false;
        c[i].waiting_time = 0;
        c[i].time = t;
        c[i].arrival_time = t;
        t = t+exponential(1/lamda);
        c[i].serv_no = 0;
        Pass.insert(c[i]);
    }
    set<customer>::iterator itr;
    for (itr = Pass.begin();itr != Pass.end(); itr++) 
    {
        if(itr->completed)
        {
            if(waiting > 0)
            {
                customer temp = wait.front();
                wait.pop();
                temp.waiting_time = itr->time - temp.time;
                temp.time = itr->time + exponential(1/mu);
                temp.completed = true;
                temp.serv_no = itr->serv_no;
                Pass.insert(temp);
                waiting--;
                //cout << "Customer finished processing" << itr->cust_id << endl;
                //cout << "Customer started processing" << temp.cust_id << endl;
            }
            else
            {
                busy[itr->serv_no] = false;
                total_busy[itr->serv_no] += itr->time - last_busy[itr->serv_no];
                
                //cout << "Customer finished processing queue is empty" << itr->cust_id << endl;
            }
        }
        else
        {
            if(waiting == buf_size)
            {
                lc++;
                //cout << "Customer is lost" << itr->cust_id<<endl;
            }
            else
            {
            if(check(busy, numofserv))
            {
                int ind = 0;
                for(int i = 0;i < numofserv;i++)
                {
                    if(!busy[i])
                    {
                        ind = i;
                        break;
                    }
                }
                busy[ind] =true;
                last_busy[ind] = itr->time;
                customer temp;
                temp.cust_id = itr->cust_id;
                temp.time = itr->time + exponential(1);
                temp.waiting_time = 0;
                temp.completed = true;
                temp.serv_no = ind;
                Pass.insert(temp);
                //cout << " CUstomer " << temp.cust_id << "Directly went for processing" << endl;
            }
            else
            {
                waiting++;
                customer temp(*itr);
                //cout << " CUstomer " << temp.cust_id << "DiStarted waiting" << endl;
                wait.push(temp);
            }
            }
        }
    }
    double mean_residence = 0;
    double W = 0;
    for (itr = Pass.begin();itr != Pass.end(); itr++) 
    {
        if(itr->completed)
        {
            mean_residence = mean_residence + itr->time - itr->arrival_time;
            completions++;
            W+=itr->waiting_time;
        }
    }
    cout << "Average waiting time\t\t\t\t" << W/N << endl;
    double T = 0;
    
    //cout << last_busy << endl;
    total_time = Pass.rbegin()->time;
    for(int i = 0;i < numofserv;i++)
    {
        cout << "Utilization for Server " << i+1 << "\t\t\t" << total_busy[i]/total_time << endl;
        T+=total_busy[i]; 
    }
    cout << "Average number of customers in the system\t" << mean_residence/total_time << endl;
    cout << "Total utilization of system\t\t\t" << T/(numofserv*total_time) << endl;
    cout << "Number of customers lost\t\t\t" << lc << endl;
    cout << "number of customers served\t\t\t"<< completions << endl;
    return 0;
}
double rand_val(int seed)
{
  const long  a =      16807;  // Multiplier
  const long  m = 2147483647;  // Modulus
  const long  q =     127773;  // m div a
  const long  r =       2836;  // m mod a
  static long x;               // Random int value (seed is set to 1)
  long        x_div_q;         // x divided by q
  long        x_mod_q;         // x modulo q
  long        x_new;           // New x value

  // Seed the RNG
  if (seed != 0) x = seed;

  // RNG using integer arithmetic
  x_div_q = x / q;
  x_mod_q = x % q;
  x_new = (a * x_mod_q) - (r * x_div_q);
  if (x_new > 0)
    x = x_new;
  else
    x = x_new + m;

  // Return a random value between 0.0 and 1.0
  return((double) x / m);
}

double exponential(double x)
{
  double z;                    // Uniform random number from 0 to 1

  // Pull a uniform RV (0 < z < 1)
  do
  {
    z = rand_val(0);
  }
  while ((z == 0) || (z == 1));

  return(-x * log(z));
}
bool check(bool* busy, int size)
{
    for(int i = 0;i < size;i++)
    {
        if(!busy[i])
        {
            return true;
        }
    }
    return false;
}